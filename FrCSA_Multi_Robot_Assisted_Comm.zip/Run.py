import numpy, random
import Proposed_FCSA, Genetic_algorithm, Tabu_search_algorithm, deep_learning


def callmain(n_robots, rounds):

    # creating nodes
    def node_creation(x_val, y_val):
        for x in range(col_n + 1):  # x columns1
            for y in range(m[x]):  # y rows
                px = 50 + x * 60 + random.uniform(-20, 20)  # node in x-axis at px
                x_val.append(px)
                py = 50 + y * 60 + random.uniform(-20, 20)  # node in y-axis at py
                y_val.append(py)

    # initial generation
    def generate(v):
        data = []
        for i in range(n_users):
            data.append(v)  # initial energy of all nodes is 1
        return data

    # packets to be send
    def node_packet(nod):
        dp = []
        for i in range(rounds):
            tem = []
            for j in range(nod):
                tem.append(random.randint(1, 10))
            dp.append(tem)
        return dp

    def process(data):
        data.sort()
        data.reverse()

    # parameter initialization
    pop_size = 10
    n_users = 100  # no. of users
    itr = 10  # number of iteration

    # to place over grid
    sq = int(numpy.sqrt(n_users))  # to make the nodes in square grid
    ex = n_users % sq  # excess nodes when make it square grid
    col_n = int((n_users - ex) / sq)  # columns for square grid
    m = []
    for i in range(col_n):
        m.append(sq)  # last column with excess nodes
    m.append(ex)

    print("\nNetwork Model..")
    data_packet = node_packet(n_users)  # packets send by each node
    Xt, Xr = 0.002, 0.002  # energy required to send, receive data
    Final_Throughput, Final_Energy_consumption, Final_Delay, Final_LLT, Final_fit = [], [], [], [], []  # Final energy,... of the nodes after all rounds

    # >> Deep learning
    Throughput, Energy, Delay, fitness = [], [], [], []
    Throughput_avg, Energy_avg, Delay_avg = [], [], []

    Throughput.append(generate(0)), Energy.append(generate(1)), Delay.append(generate(0))

    for i in range(rounds):
        x_value, y_value = [], []  # x & y value of each node
        node_creation(x_value, y_value)
        en, de, tp, fit = deep_learning.func(n_users, n_robots, Energy[i], Delay[i], data_packet[i],
                                             x_value, y_value, pop_size, Xt, Xr, Throughput[i], itr)
        Throughput.append(tp), Energy.append(en), Delay.append(de), fitness.append(fit)
        Throughput_avg.append(numpy.average(tp)), Energy_avg.append(numpy.average(en)), Delay_avg.append(
            numpy.average(de))

    Final_Throughput.append(Throughput_avg[500]), Final_Delay.append(Delay_avg[500]), Final_Energy_consumption.append(
        1 - Energy_avg[500]), Final_fit.append(fitness[500])

    print("\nGrid formation..")
    # >> Tabu search algorithm
    Throughput, Energy, Delay, fitness = [], [], [], []
    Throughput_avg, Energy_avg, Delay_avg = [], [], []

    Throughput.append(generate(0)), Energy.append(generate(1)), Delay.append(generate(0))

    for i in range(rounds):
        x_value, y_value = [], []  # x & y value of each node
        node_creation(x_value, y_value)
        en, de, tp, fit = Tabu_search_algorithm.func(n_users, n_robots, Energy[i], Delay[i], data_packet[i],
                                                     x_value, y_value, pop_size, Xt, Xr, Throughput[i], itr)
        Throughput.append(tp), Energy.append(en), Delay.append(de), fitness.append(fit)
        Throughput_avg.append(numpy.average(tp)), Energy_avg.append(numpy.average(en)), Delay_avg.append(
            numpy.average(de))

    Final_Throughput.append(Throughput_avg[500]), Final_Delay.append(Delay_avg[500]), Final_Energy_consumption.append(
        1 - Energy_avg[500]), Final_fit.append(fitness[500])

    # >>Genetic Algorithm
    Throughput, Energy, Delay, fitness = [], [], [], []
    Throughput_avg, Energy_avg, Delay_avg = [], [], []

    Throughput.append(generate(0)), Energy.append(generate(1)), Delay.append(generate(0))

    for i in range(rounds):
        x_value, y_value = [], []  # x & y value of each node
        node_creation(x_value, y_value)
        en, de, tp, fit = Genetic_algorithm.func(n_users, n_robots, Energy[i], Delay[i], data_packet[i],
                                                     x_value, y_value, pop_size, Xt, Xr, Throughput[i], itr)
        Throughput.append(tp), Energy.append(en), Delay.append(de), fitness.append(fit)
        Throughput_avg.append(numpy.average(tp)), Energy_avg.append(numpy.average(en)), Delay_avg.append(
            numpy.average(de))

    Final_Throughput.append(Throughput_avg[500]), Final_Delay.append(Delay_avg[500]), Final_Energy_consumption.append(
        1 - Energy_avg[500]), Final_fit.append(fitness[500])

    print("\nProposed FCSA based Robot positioning..")
    # >> Proposed FCSA
    Throughput, Energy, Delay, fitness = [], [], [], []
    Throughput_avg, Energy_avg, Delay_avg = [], [], []

    Throughput.append(generate(0)), Energy.append(generate(1)), Delay.append(generate(0))
    sr = []

    for i in range(rounds):
        x_value, y_value = [], []  # x & y value of each node
        node_creation(x_value, y_value)
        en, de, tp, fit = Proposed_FCSA.func(rounds, n_users, n_robots, Energy[i], Delay[i], data_packet[i],
                                             x_value, y_value, i, pop_size, Xt, Xr, col_n, sr,
                                             Throughput[i])
        Throughput.append(tp), Energy.append(en), Delay.append(de), fitness.append(fit)
        Throughput_avg.append(numpy.average(tp)), Energy_avg.append(numpy.average(en)), Delay_avg.append(
            numpy.average(de))

    Final_Throughput.append(Throughput_avg[500]), Final_Delay.append(Delay_avg[500]), \
    Final_Energy_consumption.append(1 - Energy_avg[500]), Final_fit.append(fitness[500])
    process(Final_Energy_consumption), process(Final_fit), process(Final_Delay)

    return Final_Energy_consumption, Final_fit, Final_Delay, sr
