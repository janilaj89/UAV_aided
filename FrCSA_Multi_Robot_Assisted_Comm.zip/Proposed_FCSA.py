import numpy as np
import random, obj_func


def algm(opt_nodes, pop, en,tp, de, x_value, y_value, nc, nodes, data):
    pop, dim = 10, 5  # population (row), dimension (column)
    lb, ub = 0, 1
    g, maxIter = 0, 10  # initial, max. iteration
    rho, c1, c2 = 1.0, 2.0, 1.80
    gamma, alpha, beta, Pp = 2.0, 4.0, 3.0, 0.1

    p1 = 2 * np.exp(-2 * (g / maxIter) ** 2)
    p2 = 2 / (1 + np.exp((-g + maxIter / 2) / 100))
    ch = np.ceil(pop * np.random.rand(1, pop))

    # generation of random data
    def generate(n, m, l, u):
        data = []
        for i in range(n):
            data.append(random.sample(opt_nodes, nc)) # random nodes to the size of nc
        return data

    # check the values in bound
    def check(data):
        c_data = []
        for i in range(len(data)):
            if (data[i] not in c_data) and (data[i] in opt_nodes):  # if node in opt_node but not in c_data
                c_data.append(data[i])                              # add node
            else:
                tem = random.choice(opt_nodes)                      # select random node
                while tem in c_data:                                # check if already exist/ not
                    tem = random.choice(opt_nodes)
                c_data.append(tem)
        return c_data

    def update_chameleon(mu, yt, Pt, yt1, yt2, yt3):
        for i in range(len(yt)):
            r = random.random()  # ran[0, 1]
            Gt = random.random()  # ran[0, 1]
            h = random.random()  # ran[0, 1]
            for j in range(len(yt[i])):
                r1, r2, r3 = random.random(), random.random(), random.random()  # ran[0, 1]

                # Proposed Update: FCSA
                Fr = (h * yt[i][j]) + ((h * yt1[i][j]) / 2) + (((1 - h) * yt2[i][j]) / 6) + \
                     ((h * (1 - h) * (2 - h) * yt3[i][j]) / 24)
                if r >= Pp:
                    yt[i][j] = bound(Fr * p1 * (Pt[j] - Gt) * r2 + p2 * (Gt - yt[i][j]) * r1)
                else:
                    yt[i][j] = bound(Fr + mu * (((ub - lb) * r3 + lb) * np.sign(r - 0.50)))

        yt[i] = check(yt[i])

    def update_rotation(yt, yr):
        for i in range(len(yt)):
            for j in range(len(yt[i])):
                yt[i][j] = bound(yr[j] + yt[i][j])
            yt[i] = check(yt[i])

    def update_velocity(yt, Pt, v, t, mx):
        for i in range(len(v)):
            Gt = random.random()
            for j in range(len(v[i])):
                r1, r2 = random.random(), random.random()  # ran[0, 1]
                ω = (1 - (g / mx)) ** (rho * np.sqrt(t / mx))
                a = 2590 * (1 - np.exp(-np.log(t))) + random.random()
                v_new = ω * v[i][j] + c1 * (Gt - yt[i][j]) * r1 + c2 * (Pt[j] - yt[i][j]) * r2
                yt[i][j] = bound(yt[i][j] + ((v_new) ** 2 - (v[i][j]) ** 2) / (2 * a))
                v[i][j] = v_new
            yt[i] = check(yt[i])

    soln = generate(pop, dim, lb, ub)  # initial soln. (eqn. 1)
    C1 = generate(pop, dim, 0, 0)
    C2 = generate(pop, dim, 0, 0)
    C3 = generate(pop, dim, 0, 0)
    velocity = generate(pop, dim, lb, ub)  # initial soln. (eqn. 1)

    # check bound
    def bound(val):
        val = int(val)
        if val in opt_nodes: return val
        else: return random.choice(opt_nodes)

    # loop begins
    overall_fit, overall_best, overall_llt = [], [], []
    while g < maxIter:
        fit = obj_func.calc(soln, opt_nodes, en,tp, nodes, x_value, y_value, data)  # fitness
        bst = np.argmin(fit)
        overall_fit.append(fit[bst])  # best fit
        overall_best.append(soln[bst])  # best soln.
        gPosition = overall_best[np.argmin(overall_fit)]
        mu = gamma * np.exp(-(alpha * g / maxIter) ** beta)  # eqn. (6) - parameter
        C = soln.copy()
        update_chameleon(mu, soln, gPosition, C1, C2, C3)
        update_rotation(soln, gPosition)
        update_velocity(soln, gPosition, velocity, g+1, maxIter)
        if g > 2: C3 = C2
        if g > 1: C2 = C1
        if g > 0: C1 = C
        g += 1

    bst_ind = np.argmin(overall_fit)
    return overall_best[bst_ind], overall_fit[bst_ind]


def func(rounds, nodes, n_cluster, energy, delay, data_pack, x_value, y_value, i, pop, xt, xr, col_n,
         simulation_result, throughput):
    # distance between nodes
    def distance(p1, p2):
        dist = np.sqrt((np.square(x_value[p2] - x_value[p1])) + (np.square(y_value[p2] - y_value[p1])))
        return dist

    # calculate node energy
    def calc_node_en(np, prev_en, x_t, x_r):

        en = prev_en.copy()  # copy of previous round energy
        m, n = 0.0001, 1000  # normalizing factor

        # energy drop for all nodes
        for ed in range(len(np) - 1):
            y = data_pack[np[ed]]  # no. of transmitted bits
            if ed == 0:  # source node
                if en[np[ed]] > 0:
                    dt = distance(np[ed], np[ed + 1]) / n  # distance to send the data
                    E = en[np[ed]] - (x_t * y) * dt  # only send the data to head
                    if E > 0:
                        en[np[ed]] = E
                    else:
                        en[np[ed]] = 0
                else:
                    en[np[ed]] = 0

            else:  # other nodes in path
                if np[ed] > 0:  # if 0 then no path
                    if en[np[ed]] > 0:
                        dt, dr = distance(np[ed], np[ed + 1]) / n, distance(np[ed], np[
                            ed - 1]) / n  # distance to send & receive the data
                        E = en[np[ed]] - (x_r * y) * dr - (x_t * y) * dt  # receive & send
                        if E > 0:
                            en[np[ed]] = E
                        else:
                            en[np[ed]] = 0
                    else:
                        en[np[ed]] = 0
        return en

    # calculate node delay & throughput
    def calc_node_de_tp(en, data):
        de, tp = [], []
        n_packet, packet_received = 0, 0  # total packets, packets received
        for dt in range(len(en)):  # to the size of the node
            r = random.uniform(-1, 1)
            row = np.abs(((1.0 - en[dt]) * data[dt]) + r)
            lam = data[dt]
            n_packet = n_packet + data[dt]
            packet_received = packet_received + (en[dt] * data[dt])
            tp.append((en[dt] * data[dt]) / data[dt])
            d = row / lam
            if d < 1:
                de.append(d)
            else:
                de.append(1)
        return de, tp

    # Group with Cluster Head
    def node_clustering(n, CH):
        clustered = []
        for i in range(n):
            tem = []  # tem array to store the distance value
            for j in range(len(CH)):
                tem.append(distance(i, int(CH[j])))  # distance calculation between cluster head & nodes except base station
            min_index = np.argmin(tem)
            clustered.append(CH[min_index])  # grouped cluster head is added
        return clustered

    # Pth detection
    def detection(opt_nodes, en,tp, de, pn, n_c, nodes, data):

        pth = [0]
        if n_c > len(opt_nodes): n_c = len(opt_nodes)  # non dead nodes

        # Cluster Head selection
        cluster_head, llt = algm(opt_nodes, pn, en,tp, de, x_value, y_value, n_c, nodes, data)
        grp = node_clustering(nodes, cluster_head)  # cluster head of the nodes

        pth = cluster_head.copy()
        return cluster_head, grp, pth, llt

    # nodes other than dead nodes
    def get_active_nodes(en):
        opt_n, f, Th = [], 100, 0.1 # Threshold
        for o in range(len(en)):
            if (o > 0) and (en[o] > Th):  # node with energy(not the dead node)
                if o > 1:
                    LTxi = distance(o-1, o)/f
                    llt = min(LTxi, en[o-1], en[o])
                    if llt > Th: opt_n.append(o)
                else:
                    opt_n.append(o)  # nodes other than source & destination
        return opt_n

    # get non dead nodes
    opt_nodes = get_active_nodes(energy)

    # Path from source to destination
    round_throughput, round_energy, round_delay = throughput.copy(), energy.copy(), delay.copy()
    if len(opt_nodes) > 0:
        ch, cluster_group, path, fit = detection(opt_nodes, energy,throughput, delay, pop, n_cluster, nodes, data_pack)
        round_energy = calc_node_en(path, energy, xt, xr)  # energy of nodes after the transmission
        round_delay, round_throughput = calc_node_de_tp(energy, data_pack)

    # results for simulation
    if i == 500:  # at round 500
        dead_node = []  # nodes with no energy
        for j in range(len(round_energy)):
            if round_energy[j] == 0:
                dead_node.append(j)

        simulation_result.append(x_value)  # nodes x-axis value
        simulation_result.append(y_value)  # nodes y-axis value
        simulation_result.append(n_cluster)  # no. of cluster heads
        simulation_result.append(i)  # no. of rounds
        simulation_result.append(col_n)  # no. of grid columns in simulation window
        simulation_result.append(ch)  # Cluster head nodes
        simulation_result.append(cluster_group)  # nodes grouped with cluster heads
        simulation_result.append(dead_node)  # dead nodes (nodes with energy 0)
        simulation_result.append(path)  # transmission path of last node
    return round_energy, round_delay, round_throughput, fit
