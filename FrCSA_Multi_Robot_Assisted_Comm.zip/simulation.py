import time, random, numpy as np
from matplotlib import pyplot as plt
from matplotlib import animation


def displayStarting(n_robots, selected_node, nei_nodes):

    robot_lc = []
    for i in range(n_robots):
        robot_lc.append([random.randint(0, 500), random.randint(0, 500)])

    n_nodes = 100
    user_under_robot = []
    for i in range(n_nodes):
        user_under_robot.append(i)

    # to place nodes over grid
    sq = int(np.sqrt(n_nodes))  # to make the nodes in square grid -- take sqrt of nodes
    ex = n_nodes % sq  # excess nodes when make it square grid
    col_n = int((n_nodes - ex) / sq)  # columns for square grid
    m = []
    for i in range(col_n):
        m.append(sq)  # last column with excess nodes
    m.append(ex)

    # creating nodes
    record_axis = []
    for xx in range(col_n + 1):  # x columns1
        for yy in range(m[xx]):  # y rows
            px = 50 + xx * 60 + random.uniform(-20, 20)  # node in x-axis at px
            py = 50 + yy * 60 + random.uniform(-20, 20)  # node in y-axis at py
            record_axis.append([px, py])

    xs_m, ys_m = [], []
    for i in range(len(selected_node)):  # each robot
        nei = []
        xn, yn = [], []  # position of user nodes
        for j in range(len(nei_nodes)):  # user under each robot
            if nei_nodes[j] == selected_node[i]:  # if user under coverage of robot
                nei.append(j)
                xn.append(record_axis[j][0])
                yn.append(record_axis[j][1])
        # newly moved position of selected robot
        xs_m.append(int(np.average(xn)))
        ys_m.append(int(np.average(yn)))
    fig = plt.figure()
    plt.style.use('seaborn')  # seaborn background
    fig.set_dpi(100)  # dpi of figure is set to 125
    fig.set_size_inches(7, 7)

    ax = plt.axes(xlim=(0, 650), ylim=(0, 650))
    ax.grid(True, color='grey', linestyle='dotted', linewidth=1)  # grid (dotted grey)
    patch = []
    for i in range(len(robot_lc)):
        patch.append(plt.Circle((5, -5), 12, fc='r'))  # robot as red

    patch_1 = []
    for i in range(len(nei_nodes)):
        patch_1.append(plt.Circle((5, -5), 7, fc='b'))  # user as blue

    # initial node position in window
    def init():

        ''' user location'''
        # add the position
        for ii in range(len(record_axis)):
            patch_1[ii].center = (record_axis[ii][0], record_axis[ii][1])

        # add the positions to plot
        for ii in range(len(record_axis)):
            ax.add_patch(patch_1[ii])

        '''robot location'''
        # add the position
        for ii in range(len(robot_lc)):
            patch[ii].center = (robot_lc[ii][0], robot_lc[ii][1])

        # add the positions to plot
        for ii in range(len(robot_lc)):
            ax.add_patch(patch[ii])
        return patch, patch_1

    def displayGraph(i):
        for ii in range(len(selected_node)):
            x, y = patch[ii].center
            patch[ii].center = (x, y)  # add the selected node
        time.sleep(1)

        if i == 2:  # at frame 2
            for ii in range(len(selected_node)):
                patch[ii].center = (xs_m[ii], ys_m[ii])  # move nodes to its new position
        if i == 3:  # link nodes at frame 3
            plt.scatter(xs_m, ys_m, s=25000, facecolors='none', color='green', linestyle='--', linewidth=1.5)

        return patch, patch_1

    # display animation
    anim = animation.FuncAnimation(fig, displayGraph, init_func=init, frames=5, blit=False, repeat=False)
    plt.show()  # show the plot
    plt.close()
