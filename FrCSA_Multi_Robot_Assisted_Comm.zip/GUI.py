import PySimpleGUI as sg
import numpy as np
import matplotlib.pyplot as plt
import Run
import simulation
sg.change_look_and_feel('GreenMono')    # for theme
import warnings
warnings.filterwarnings("ignore", category=RuntimeWarning)
warnings.filterwarnings("ignore", category=np.VisibleDeprecationWarning)

# Designing layout
layout = [[sg.Text("")], [sg.Text("\t\tNumber of Robots\t"), sg.InputText(size=(20, 2))],
          [sg.Text("\t\tNumber of Rounds\t"), sg.InputText(size=(20, 2)), sg.Text("\t"), sg.Button("START", size=(20, 2))],
          [sg.Text("\n")],
          [sg.Text("\t\t\t     Energy Consumption\t\tFitness\t\t        Delay\t")],
          [sg.Text('Deep learning\t\t'), sg.In(key='11',size=(20,20)), sg.In(key='12',size=(20,20)), sg.In(key='13',size=(20,20))],
          [sg.Text('Tabu search algorithm\t'), sg.In(key='21',size=(20,20)), sg.In(key='22',size=(20,20)), sg.In(key='23',size=(20,20))],
          [sg.Text('Genetic Algorithm\t\t'), sg.In(key='31',size=(20,20)), sg.In(key='32',size=(20,20)), sg.In(key='33',size=(20,20))],
          [sg.Text('Proposed FCSA\t\t'), sg.In(key='41',size=(20,20)), sg.In(key='42',size=(20,20)), sg.In(key='43',size=(20,20))], [sg.Text("\n")],
          [sg.Text("\t\t\t\t\t\t\t\t\t\t"), sg.Button('Close', size=(10, 1))], [sg.Text("")]]


# to plot graph
def plot_graph(result_1, result_2, result_3):

    loc, result = [], []
    result.append(result_1)  # appending the result
    result.append(result_2)
    result.append(result_3)

    result = np.transpose(result)

    # labels for bars
    labels = ['Deep learning', 'Tabu search algorithm', 'Genetic Algorithm', 'Proposed FCSA']  # x-axis labels
    tick_labels = ['Energy Consumption', 'Fitness', 'Delay']  # metrics
    bar_width, s = 0.15, 0.025  # bar width, space between bars

    for i in range(len(result)):  # allocating location for bars
        if i is 0:  # initial location - 1st result
            tem = []
            for j in range(len(tick_labels)):
                tem.append(j + 1)
            loc.append(tem)
        else:  # location from 2nd result
            tem = []
            for j in range(len(loc[i - 1])):
                tem.append(loc[i - 1][j] + s + bar_width)
            loc.append(tem)

    # plotting a bar chart
    for i in range(len(result)):
        plt.bar(loc[i], result[i], label=labels[i], tick_label=tick_labels, width=bar_width)

    plt.legend()  # show a legend on the plot -- here legends are metrics
    plt.show()  # to show the plot


# Create the Window layout
window = sg.Window('GUI', layout)

# event loop
while True:
    event, value = window.read()  # displays the window
    if event == "START":
        n_robots, n_rounds = int(value[0]), int(value[1])
        Energy_Consumption, fit, Delay, SR = Run.callmain(n_robots, n_rounds)
        window.Element('11').Update(Energy_Consumption[0]), window.Element('12').Update(fit[0])
        window.Element('13').Update(Delay[0])
        window.Element('21').Update(Energy_Consumption[1]), window.Element('22').Update(fit[1])
        window.Element('23').Update(Delay[1])
        window.Element('31').Update(Energy_Consumption[2]), window.Element('32').Update(fit[2])
        window.Element('33').Update(Delay[2])
        window.Element('41').Update(Energy_Consumption[3]), window.Element('42').Update(fit[3])
        window.Element('43').Update(Delay[3])
        print("\nRunning Simulation.")
        simulation.displayStarting(n_robots, SR[5], SR[6])
        print("\nDone..")
        plot_graph(Energy_Consumption, fit, Delay)

    if event == 'Close':
        window.close()
        break