import random, numpy as np

BW = 1  # link Bandwidth (1 Mbps)


# distance between nodes
def distance(p1, p2, x_value, y_value):
    dist = np.sqrt((np.square(x_value[p2] - x_value[p1])) + (np.square(y_value[p2] - y_value[p1])))  # distance formula
    return dist


def euclidean_distance(p1, p2, x_value, y_value):
    n = 1000
    point1 = np.array([x_value[p1], y_value[p1]]) / n
    point2 = np.array([x_value[p2], y_value[p2]]) / n

    # finding sum of squares
    sum_sq = np.sum(np.square(point1 - point2))

    # return Euclidean distance
    return np.sqrt(sum_sq)


# Node grouping
def node_clustering(n, CH, xv, yv):
    clustered = []
    for i in range(n):
        tem = []  # tem array to store the distance value
        for j in range(len(CH)):
            tem.append(distance(i, CH[j], xv, yv))  # distance calculation between cluster head & nodes except base station
        min_index = np.argmin(tem)
        clustered.append(CH[min_index])  # grouped cluster head is added
    return clustered


# summation of node energy
def calc_energy_tp(nodes, en, tp):
    en_summ, tp_summ = 0, 0
    for i in range(len(nodes)):
        en_summ += en[nodes[i]]
        tp_summ += tp[nodes[i]]
    return en_summ, tp_summ


# distance calculation
def calc_dist(soln, cluster_node, xv, yv):
    ED_summ, EDD_summ, f = 0, 0, 100  # F => Normalization
    for i in range(len(soln)):
        d_summ, dd_summ = 0, 0
        for j in range(len(cluster_node[i])):
            dd_summ += (euclidean_distance(soln[i], cluster_node[i][j], xv, yv) / f) + \
                       euclidean_distance(cluster_node[i][j], len(xv) - 1, xv, yv) / f
            d_summ += euclidean_distance(soln[i], cluster_node[i][j], xv, yv) / f  # distance
        ED_summ += d_summ
        EDD_summ += dd_summ
    return EDD_summ / ED_summ


# delay calculation
def calc_delay(M):
    M_summ, Max_M = 0, []
    for i in range(len(M)): Max_M.append(len(M[i]))  # nodes in each cluster
    for i in range(len(M)):
        M_summ += (len(M[i]) / max(Max_M))  # M[i] => nodes in that cluster
    return M_summ


# grouping nodes
def group_nodes(nodes, cg):
    nodes_clustered = []
    for i in range(len(nodes)):
        tem = []
        for j in range(len(cg) - 1):  # -1, since last node is base station
            if nodes[i] == cg[j]:  # node in that cluster
                tem.append(j)
        nodes_clustered.append(tem)  # group nodes in same cluster
    return nodes_clustered


# fitness calculation
def calc_coverage(ED):
    Cbw, Ptx = 1.0, random.random()  # signal bandwidth, power delivered
    Gmax, n, f, nf, nf1 = 1.0, 3.3, 2, 10e4, 10e2  # max. power, propagation exponent, channel frequency
    N = (-174 + 10 * np.log10(Cbw)) / nf1  # eqn. (7)
    NF = random.random()  # noise figure
    Gij = 10 * np.log10(10 ** (Gmax / 20) * (np.cos(45) ** 2))  # eqn. (5)
    RSSI = (Ptx + 14755 + Gij - n * (10 * (np.log10(np.abs(ED)))) - 20 * np.log10(f)) / nf
    SNR = RSSI - NF - N  # eqn. (6)
    return np.abs(SNR)


def calc(soln, opt_node, en, tp, nodes, xv, yv, data):
    fit, llt, f, N = [], [], 100, 5
    for i in range(len(soln)):
        grp = node_clustering(nodes, soln[i], xv, yv)  # soln. with nodes
        nodes_n_cluster = group_nodes(soln[i], grp)  # group the nodes

        H, K = len(soln[i]), len(opt_node)  # soln. size, no. of nodes in soln.
        E, TP = calc_energy_tp(soln[i], en, tp)
        EC = 1 - (E / H)  # Energy consumption
        TP /= H  # throughput
        d = calc_dist(soln[i], nodes_n_cluster, xv, yv) / (H * K)  # distance
        D = calc_delay(nodes_n_cluster) / H  # delay
        C = calc_coverage(d)

        F = (d + (1 - TP) + D + (1 - C) + EC) / N  # Fitness formula
        fit.append(F)
    return fit
