import random, obj_func, numpy as np


# distance between nodes
def dist(p1, p2, x_value, y_value):
    dt = np.sqrt((np.square(x_value[p2] - x_value[p1])) + (np.square(y_value[p2] - y_value[p1])))  # distance formula
    return dt


def algm(opt_nodes, PopSize, en, tp, x_value, y_value, num_dimensions, nodes, data, max_iter):

    # establish the solution
    def generate(ps, nd):
        gen_data = []
        for i in range(0, ps):
            tem = []
            for j in range(nd):
                tem.append(random.choice(opt_nodes))
            gen_data.append(tem)
        return gen_data

    def crossover(X, Ft):
        C_data = []
        ft = Ft.copy()
        inx = []
        for i in range(len(ft)):
            nx = np.argmin(ft)
            inx.append(nx)
            ft[nx] = float('inf')
        for i in range(len(X)):
            C_data.append(X[inx[i]])
        return C_data

    def mutation(S, ps, nd):
        m_data = []
        for i in range(0, len(S)):
            tem = []
            for j in range(nd):
                tem.append(random.choice(opt_nodes))
            m_data.append(tem)
        return m_data

    # begin optimization loop
    sol = generate(PopSize, num_dimensions)
    solutions, best_fit = [], []
    i = 0
    while i < max_iter:
        # evaluate fitness
        fit = obj_func.calc(sol, opt_nodes, en, tp, nodes, x_value, y_value, data)
        index = np.argmin(fit)

        # selection
        best_fit.append(fit[index])
        solutions.append(sol[index])

        # crossover
        sol = crossover(sol, fit)

        # mutation
        sol = mutation(sol, PopSize, num_dimensions)
        i += 1

    best_index = np.argmin(best_fit)
    best_solution = solutions[best_index]

    return best_solution, best_fit[best_index]


def func(nodes, n_cluster, energy, delay, data_pack, x_value, y_value, pop, xt, xr, throughput, itr):

    # calculate node energy
    def calc_node_en(np, prev_en, x_t, x_r):

        en = prev_en.copy()  # copy of previous round energy
        m, n = 0.0005, 1000  # normalizing factor
        x_t, x_r = x_t + m, x_r + m

        # energy drop for all nodes
        for ed in range(len(np) - 1):
            y = data_pack[np[ed]]  # no. of transmitted bits
            if ed == 0:  # source node
                if en[np[ed]] > 0:
                    dt = dist(np[ed], np[ed + 1], x_value, y_value) / n  # distance to send the data
                    E = en[np[ed]] - (x_t * y) * dt  # only send the data to head
                    if E > 0:
                        en[np[ed]] = E
                    else:
                        en[np[ed]] = 0
                else:
                    en[np[ed]] = 0

            else:  # other nodes in path
                if np[ed] > 0:  # if 0 then no path
                    if en[np[ed]] > 0:
                        dt, dr = dist(np[ed], np[ed + 1], x_value, y_value) / n, dist(np[ed], np[ed - 1], x_value, y_value) / n  # distance to send & receive the data
                        E = en[np[ed]] - (x_r * y) * dr - (x_t * y) * dt  # receive & send
                        if E > 0:
                            en[np[ed]] = E
                        else:
                            en[np[ed]] = 0
                    else:
                        en[np[ed]] = 0
        return en

    # calculate node delay & throughput
    def calc_node_de_tp(en, data):
        de, tp = [], []
        n_packet, packet_received = 0, 0  # total packets, packets received
        for dt in range(len(en)):  # to the size of the node
            r = random.uniform(-1, 1)
            row = np.abs(((1.0 - en[dt]) * data[dt]) + r)
            lam = data[dt]
            n_packet = n_packet + data[dt]
            packet_received = packet_received + (en[dt] * data[dt])
            tp.append((en[dt] * data[dt]) / data[dt])
            d = row / lam
            if d < 1:
                de.append(d)
            else:
                de.append(1)
        return de, tp

    # User with robot
    def area_coverage(n, CV):
        coverage = []
        for i in range(n):
            tem = []  # tem array to store the distance value
            for j in range(len(CV)):
                tem.append(dist(i, CV[j], x_value, y_value))  # distance calculation between robot & user
            min_index = np.argmin(tem)
            coverage.append(CV[min_index])  # area covered
        return coverage

    # Robot positioning
    def positioning(opt_nodes, en, tp, pn, n_c, nodes, data):

        if n_c > len(opt_nodes): n_c = len(opt_nodes)  # non dead nodes

        # robot positioning
        robot_pos, ft = algm(opt_nodes, pn, en, tp, x_value, y_value, n_c, nodes, data, itr)
        grp = area_coverage(nodes, robot_pos)  # cluster head of the nodes

        pth = robot_pos.copy()
        return robot_pos, grp, pth, ft

    # nodes other than dead nodes
    def get_active_nodes(en):
        opt_n = []
        for o in range(len(en)):
            if (o > 0) and (en[o] > 0):  # node with energy(not the dead node)
                opt_n.append(o)  # nodes other than source & destination
        return opt_n

    # get non dead nodes
    opt_nodes = get_active_nodes(energy)

    # Path from source to destination
    round_throughput, round_energy, round_delay = throughput.copy(), energy.copy(), delay.copy()
    if len(opt_nodes) > 0:
        ch, cluster_group, path, fit = positioning(opt_nodes, energy, throughput, pop, n_cluster, nodes, data_pack)
        round_energy = calc_node_en(path, energy, xt, xr)  # energy of nodes after the transmission
        round_delay, round_throughput = calc_node_de_tp(energy, data_pack)

    return round_energy, round_delay, round_throughput, fit
